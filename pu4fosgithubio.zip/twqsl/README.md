# twqsl
Trusted Web QSL Signer

Sign offline ADI files using TQSL P12 file to a TQ8 LOTW file ready to upload.
